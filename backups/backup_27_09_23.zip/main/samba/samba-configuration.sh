#!/bin/bash

echo -e "admin\nadmin" | smbpasswd -s -a "xpto"
echo -e "usr1\nusr1" | smbpasswd -s -a "xpto"
echo -e "usr2\nusr2" | smbpasswd -s -a "xpto"

exec smbd --foreground --no-process-group